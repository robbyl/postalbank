<?php

include_once($CFG->dirroot.'/calendar/renderer.php');
include_once($CFG->dirroot.'/theme/synergy_bootstrap/renderers/core_renderer.php');
class theme_tpb_core_calendar_renderer extends core_calendar_renderer {

	 /**
     * Adds a pretent calendar block
     *
     * @param block_contents $bc
     * @param mixed $pos BLOCK_POS_RIGHT | BLOCK_POS_LEFT
     */
    public function add_pretend_calendar_block(block_contents $bc, $pos=BLOCK_POS_RIGHT) {
    	global $PAGE;

    	if ($PAGE->pagetype == 'calendar-event') {
    		return false;
    	} else {
    		$this->page->blocks->add_fake_block($bc, $pos);
    	}
    }

}

class theme_tpb_core_renderer extends theme_synergy_bootstrap_core_renderer {

protected function render_custom_menu(custom_menu $menu) {
        global $CFG;

        // TODO: eliminate this duplicated logic, it belongs in core, not
        // here. See MDL-39565.
        $addlangmenu = false;
        $langs = get_string_manager()->get_list_of_translations();
        if (count($langs) < 2
            or empty($CFG->langmenu)
            or ($this->page->course != SITEID and !empty($this->page->course->lang))) {
            $addlangmenu = false;
        }

        if (!$menu->has_children() && $addlangmenu === false) {
            return '';
        }

        if ($addlangmenu) {
            $language = $menu->add(get_string('language'), new moodle_url('#'), get_string('language'), 10000);
            foreach ($langs as $langtype => $langname) {
                $language->add($langname, new moodle_url($this->page->url, array('lang' => $langtype)), $langname);
            }
        }

        $content = '<ul class="nav menu">';
        foreach ($menu->get_children() as $item) {
            $content .= $this->render_custom_menu_item($item, 1);
        }

        return $content.'</ul>';
    }
    
}